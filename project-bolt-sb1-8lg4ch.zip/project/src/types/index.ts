export interface NavItem {
  label: string;
  href: string;
  icon?: React.ComponentType;
}

export interface Methodology {
  title: string;
  description: string;
  color: string;
  icon: string;
}

export interface Service {
  title: string;
  description: string;
  icon: string;
  benefits: string[];
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  company: string;
  content: string;
  image: string;
}