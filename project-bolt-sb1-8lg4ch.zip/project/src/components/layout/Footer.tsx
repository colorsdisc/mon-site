import React from 'react';
import { Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold">Colors DISC</h3>
            <p className="text-gray-400">
              Développez le potentiel de vos équipes grâce à nos formations et accompagnements personnalisés.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li><a href="#services" className="text-gray-400 hover:text-white">Formation DISC</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white">Coaching individuel</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white">Séminaires d'entreprise</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white">Analyse comportementale</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Liens utiles</h4>
            <ul className="space-y-2">
              <li><a href="#about" className="text-gray-400 hover:text-white">À propos</a></li>
              <li><a href="#methodologies" className="text-gray-400 hover:text-white">Méthodologies</a></li>
              <li><a href="#testimonials" className="text-gray-400 hover:text-white">Témoignages</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Suivez-nous</h4>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Colors DISC. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
}