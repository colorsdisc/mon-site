import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Methodology } from '../../types';

const methodologies: Methodology[] = [
  {
    title: 'DISC',
    description: 'Comprendre les styles comportementaux pour une meilleure communication et collaboration.',
    color: 'from-red-500 to-yellow-500',
    icon: '🎯'
  },
  {
    title: 'Forces Motrices',
    description: 'Identifier les motivations profondes qui guident nos décisions et actions.',
    color: 'from-yellow-500 to-green-500',
    icon: '⚡'
  },
  {
    title: 'GOLDEN',
    description: 'Analyser les préférences naturelles pour optimiser le potentiel individuel et collectif.',
    color: 'from-blue-500 to-purple-500',
    icon: '🌟'
  }
];

export function Methodologies() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section id="methodologies" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Nos Méthodologies
          </h2>
          <p className="mt-4 text-xl text-gray-500">
            Des outils éprouvés pour développer vos soft skills
          </p>
        </div>

        <div ref={ref} className="mt-20 grid gap-8 md:grid-cols-3">
          {methodologies.map((method, index) => (
            <motion.div
              key={method.title}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className="relative group"
            >
              <div className={`absolute inset-0 bg-gradient-to-r ${method.color} rounded-lg opacity-50 group-hover:opacity-100 transition-opacity duration-300`} />
              <div className="relative p-8 bg-white rounded-lg shadow-xl">
                <div className="text-4xl mb-4">{method.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{method.title}</h3>
                <p className="text-gray-600">{method.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}