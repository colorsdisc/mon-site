import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Users, Target, Brain, Presentation } from 'lucide-react';
import { Service } from '../../types';

const services: Service[] = [
  {
    title: 'Formation DISC',
    description: 'Développez vos compétences en communication et adaptabilité',
    icon: 'Users',
    benefits: [
      'Comprendre les différents styles de communication',
      'Améliorer les relations interpersonnelles',
      'Optimiser le travail d\'équipe'
    ]
  },
  {
    title: 'Coaching individuel',
    description: 'Accompagnement personnalisé pour votre développement',
    icon: 'Target',
    benefits: [
      'Identifier vos points forts',
      'Développer votre leadership',
      'Atteindre vos objectifs professionnels'
    ]
  },
  {
    title: 'Analyse comportementale',
    description: 'Évaluation approfondie de votre profil DISC',
    icon: 'Brain',
    benefits: [
      'Rapport détaillé de votre profil',
      'Plan d\'action personnalisé',
      'Suivi des progrès'
    ]
  },
  {
    title: 'Séminaires d\'entreprise',
    description: 'Solutions sur mesure pour vos équipes',
    icon: 'Presentation',
    benefits: [
      'Team building efficace',
      'Cohésion d\'équipe renforcée',
      'Performance collective améliorée'
    ]
  }
];

const iconComponents = {
  Users,
  Target,
  Brain,
  Presentation
};

export function Services() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Nos Services
          </h2>
          <p className="mt-4 text-xl text-gray-500">
            Des solutions adaptées à vos besoins de développement
          </p>
        </div>

        <div ref={ref} className="mt-20 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {services.map((service, index) => {
            const Icon = iconComponents[service.icon as keyof typeof iconComponents];
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="bg-white rounded-lg shadow-xl p-8"
              >
                <div className="text-disc-blue mb-4">
                  <Icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  {service.title}
                </h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <ul className="space-y-2">
                  {service.benefits.map((benefit, i) => (
                    <li key={i} className="flex items-start">
                      <span className="text-disc-green mr-2">•</span>
                      <span className="text-sm text-gray-600">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}