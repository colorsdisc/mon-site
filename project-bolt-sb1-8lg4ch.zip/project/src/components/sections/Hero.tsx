import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pt-16" id="accueil">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
        <div className="relative z-10 lg:w-full lg:max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl md:text-6xl lg:text-5xl xl:text-6xl">
              <span className="block">Révélez le potentiel de</span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-yellow-500 to-blue-500">
                vos équipes
              </span>
            </h1>
            <p className="mt-6 text-xl text-gray-500 max-w-lg">
              Découvrez la puissance des outils DISC, Forces Motrices et GOLDEN pour transformer
              votre leadership et la dynamique de vos équipes.
            </p>
            <div className="mt-10 flex gap-4">
              <a
                href="#contact"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                Commencer maintenant
                <ArrowRight className="ml-2 -mr-1 h-5 w-5" />
              </a>
              <a
                href="#methodologies"
                className="inline-flex items-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                En savoir plus
              </a>
            </div>
          </motion.div>
        </div>
      </div>
      <div className="relative h-64 sm:h-72 md:h-96 lg:absolute lg:inset-y-0 lg:right-0 lg:h-full lg:w-1/2 mt-8 lg:mt-0">
        <img
          className="absolute inset-0 w-full h-full object-cover rounded-l-3xl"
          src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80"
          alt="Équipe en formation"
        />
      </div>
    </div>
  );
}