import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Award, CheckCircle } from 'lucide-react';

export function About() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-w-3 aspect-h-2 rounded-lg overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80"
                alt="Formation professionnelle"
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-8 -right-8 bg-gradient-to-br from-disc-red to-disc-yellow p-8 rounded-lg shadow-xl">
              <div className="flex items-center space-x-2">
                <Award className="w-8 h-8 text-white" />
                <span className="text-white font-bold">Certifié DISC</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-10 lg:mt-0"
          >
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Notre Expertise
            </h2>
            <p className="mt-4 text-lg text-gray-600">
              Depuis plus de 10 ans, Colors DISC accompagne les entreprises et les individus dans leur développement professionnel grâce à des méthodes éprouvées et personnalisées.
            </p>
            
            <div className="mt-8 space-y-4">
              {[
                'Plus de 500 professionnels formés',
                'Certification internationale DISC',
                'Approche personnalisée',
                'Résultats mesurables'
              ].map((item, index) => (
                <div key={index} className="flex items-center">
                  <CheckCircle className="w-5 h-5 text-disc-green mr-2" />
                  <span className="text-gray-700">{item}</span>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <a
                href="#contact"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-disc-blue hover:bg-opacity-90 transition-colors duration-200"
              >
                Découvrir notre approche
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}